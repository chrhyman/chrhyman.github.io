https://github.com/IrisShaders/Iris/issues/2321#issuecomment-2408644317

Iris Shaders issue with Spectator Mode/Free cam resolved and this comment links to the build that has the .jar artifact build.5425

This will likely be merged into Iris at some point, where this version and README will no longer be necessary.